package com.wyday.turboactivate;

public interface TrialChangeEvent
{
	void TrialChange(int status);
}
