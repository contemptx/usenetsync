package com.wyday.turboactivate;

public class BoolRef
{
	boolean value;

	public boolean getValue()
	{
		return value;
	}

	public void setValue(boolean val)
	{
		value = val;
	}
}