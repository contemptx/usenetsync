package com.wyday.turboactivate;

public class TurboActivateException extends Exception
{
	public TurboActivateException(String message)
	{
		super(message);
	}
}